#!/bin/bash
bconsole -c /etc/bacula/bconsole.conf <<END_OF_DATA
query
12
843
END_OF_DATA
