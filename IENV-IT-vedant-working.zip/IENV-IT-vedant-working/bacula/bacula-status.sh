#!/bin/bash
bconsole -c /etc/bacula/bconsole.conf <<END_OF_DATA
status client
6
END_OF_DATA
