Location for various utilities for IE IT needs
