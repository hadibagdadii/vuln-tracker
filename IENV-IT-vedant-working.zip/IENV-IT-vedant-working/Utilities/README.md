Location for various utilities for JMIE IT needs
